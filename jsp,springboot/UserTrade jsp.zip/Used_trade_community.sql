use basicjsp;

drop table member;

create table member(
	mem_num int not null auto_increment primary key,
    name varchar(30) not null,
    id varchar(30) not null unique,
    passwd varchar(30) not null,
    nickname varchar(30) not null,
    email varchar(30) unique,
    phone varchar(30),
    RRN varchar(30) not null unique,
    Ranks int default 1 not null
);

select * from member;

INSERT INTO member (name, id, passwd, nickname, email, phone, RRN, Ranks) values ('관리자','admin','1234','admin','admin@gmail.com','010-1234-5678','000000-0000000',0);
INSERT INTO member (name, id, passwd, nickname, email, phone, RRN) values ('people01','people01','1234','people01','people01@gmail.com','010-1234-7897','123456-1234567');

drop table board;


create table board(
num int not null primary key auto_increment,
writer varchar(10) not null,
email varchar(30),
subject varchar(50) not null,
passwd varchar(12) not null,
reg_date datetime not null,
readcount int default 0,
ref int not null,
re_step smallint not null,
re_level smallint not null,
content text not null,
ip varchar(20) not null,
headline varchar(30) not null);

select*from board;


INSERT INTO board (writer, email, subject, passwd, reg_date, readcount, ref, re_step, re_level, content, ip, headline) VALUES
('관리자', 'admin@gmail.com', '첫 번째 게시물입니다.', '1234', NOW(), 0, 0, 0, 0, '첫 번째 게시물 내용입니다.', '127.0.0.1', '사고팝니다.'),
('사용자1', 'user1@gmail.com', '두 번째 게시물입니다.', '1234', NOW(), 0, 0, 0, 0, '두 번째 게시물 내용입니다.', '127.0.0.1', '사고팝니다.'),
('사용자2', 'user2@gmail.com', '세 번째 게시물입니다.', '1234', NOW(), 0, 0, 0, 0, '세 번째 게시물 내용입니다.', '127.0.0.1', '사고팝니다.'),
('사용자3', 'user3@gmail.com', '네 번째 게시물입니다.', '1234', NOW(), 0, 0, 0, 0, '네 번째 게시물 내용입니다.', '127.0.0.1', '사고팝니다.'),
('사용자4', 'user4@gmail.com', '다섯 번째 게시물입니다.', '1234', NOW(), 0, 0, 0, 0, '다섯 번째 게시물 내용입니다.', '127.0.0.1', '사고팝니다.');
