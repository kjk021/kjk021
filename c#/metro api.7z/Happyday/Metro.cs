﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Happyday
{
    internal class Metro
    {
        public string day { get; set; }
        public string stationName { get; set; }
        public string boardingAlighting { get; set; }

    }
}
