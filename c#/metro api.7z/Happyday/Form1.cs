﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace Happyday
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                // 웹에서 XML 데이터를 다운로드
                string url = "https://api.odcloud.kr/api/15002503/v1/uddi:eb336a48-6f99-4032-93ef-fec002d16c85?page=1&perPage=200&returnType=XML&serviceKey=1MSHh38U0IIKU0fBm2GLMagKVzPGbrpW3W2AGKEUprs3zoIkM46Nr%2FsEcfZI6jaLYx%2BbqaXQO6R8UgdaKtROxA%3D%3D";
                string xmlString;
             

               
                XElement xe = XElement.Load(url);             
                List<Metro> metro = new List<Metro>();


                foreach (var item in xe.Descendants("item"))
                {
                    Metro m = new Metro();
                    foreach (var myitem in item.Descendants("col"))
                    {
                        //if(   )(string)myitem.Attribute("name")
                        if ( ((string)myitem.Attribute("name")).Equals("일계")  )
                        {
                            m.day = myitem.Value;
                        }
                        if (((string)myitem.Attribute("name")).Equals("역명"))
                        {
                            m.stationName   = myitem.Value;
                        }
                        if (((string)myitem.Attribute("name")).Equals("승하차"))
                        {
                            m.boardingAlighting = myitem.Value;
                        }
                    }
                    metro.Add(m);
                }


                    // XML에서 필요한 값 추출하여 Metro 객체로 만들기
                //    foreach (var item in xe.Descendants("item"))
                //{
                //    string colName = item.Attribute("name").Value;
                //    string colValue = item.Value;

                //    if (colName == "일계")
                //    {
                //        Metro m = new Metro()
                //        {
                //            day = colValue
                //        };
                //        metro.Add(m);
                //    }
                //    else if (colName == "역명")
                //    {
                //        if (metro.Count > 0)
                //        {
                //            metro.Last().stationName = colValue;
                //        }
                //        else
                //        {
                //            Metro m = new Metro();
                //            m.stationName = colValue;
                //            metro.Add(m);
                //        }
                //    }
                //    else if (colName == "승하차")
                //    {
                //        if (metro.Count > 0)
                //        {
                //            metro.Last().boardingAlighting = colValue;
                //        }
                //        else
                //        {
                //            Metro m = new Metro();
                //            m.boardingAlighting = colValue;
                //            metro.Add(m);
                //        }
                //    }
                //}

                // DataGridView에 데이터 바인딩
                dataGridView1.DataSource = null;
                dataGridView1.DataSource = metro;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error occurred: {ex.Message}");
            }
        }
    }
 }
  

